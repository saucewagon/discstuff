Author: Alexander Steel
V00855144

CSC 360: Fall 2017
Assignment 3


Usage:

% make
% ./discinfo <disc image file>
% ./disclist <disc image file>
% ./diskget <disc image file>





